function setup() {
  createCanvas(windowWidth, windowHeight);
  background(200); // Darker background for contrast with purple
}

function draw() {
  // Clear the canvas with a transparent stroke
  noFill();
  stroke(0, 0); // Transparent black stroke
  rect(0, 0, width, height);

  // Reduce drawing frequency for slower animation
  if (frameCount % 4 === 0) {
    // Define the number of patterns
    const numPatterns = 2; // Fewer patterns for slower movement

    // Loop through each pattern
    for (let i = 0; i < numPatterns; i++) {
      const x = random(width);
      const y = random(height);
      const size = random(50, 150);
      const angle = random(0, TWO_PI);

      // Choose a random pattern type with purple hues
      switch (floor(random(4))) {
        case 0:
          drawStripes(x, y, size, angle, random(150, 220)); // Purple hues
          break;
        case 1:
          drawCircles(x, y, size, angle, random(150, 220)); // Purple hues
          break;
        case 2:
          drawSquares(x, y, size, angle, random(150, 220)); // Purple hues
          break;
        case 3:
          drawGrid(x, y, size, angle, random(150, 220)); // Purple hues
          break;
      }
    }
  }
}

function drawStripes(x, y, size, angle, hue) {
  push();
  translate(x, y);
  rotate(angle);
  for (let i = 0; i < size; i += 5) {
    const saturation = random(50, 100);
    const brightness = random(50, 100);
    stroke(color(hue, saturation, brightness));
    strokeWeight(random(2, 5));
    line(-size / 2, i, size / 2, i);
  }
  pop();
}

function drawCircles(x, y, size, angle, hue) {
  push();
  translate(x, y);
  rotate(angle);
  for (let i = 0; i < size; i += 10) {
    const saturation = random(50, 100);
    const brightness = random(50, 100);
    fill(color(hue, saturation, brightness, random(50, 100)));
    ellipse(0, 0, i, i);
  }
  pop();
}

function drawSquares(x, y, size, angle, hue) {
  push();
  translate(x, y);
  rotate(angle);
  for (let i = 0; i < size; i += 15) {
    const saturation = random(50, 100);
    const brightness = random(50, 100);
    fill(color(hue, saturation, brightness));
    rect(-size / 2, -size / 2, i, i);
  }
  pop();
}

function drawGrid(x, y, size, angle, hue) {
  push();
  translate(x, y);
  rotate(angle);
  const cellSize = 10;
  for (let i = -size / 2; i < size / 2; i += cellSize) {
    for (let j = -size / 2; j < size / 2; j += cellSize) {
      const saturation = random(50, 100);
      const brightness = random(50, 100);
      fill(color(hue, saturation, brightness));
      rect(i, j, cellSize, cellSize);
    }
  }
  pop();
}
